# Copyright (c) 2024-2026 Ziqi Fan
# SPDX-License-Identifier: Apache-2.0

"""Configuration for Unitree robots.
Reference: https://github.com/unitreerobotics/unitree_ros
"""

import isaaclab.sim as sim_utils
from isaaclab.actuators import ActuatorNetMLPCfg
from isaaclab.assets.articulation import ArticulationCfg

from robot_lab.assets import ISAACLAB_ASSETS_DATA_DIR

##
# Configuration
##

MY_DOG_ACTUATOR_NET_PATH = f"source/robot_lab/data/ActuatorNets/my_dog/motor.pt"

MY_DOG_CFG = ArticulationCfg(
    spawn=sim_utils.UrdfFileCfg(
        fix_base=False,
        merge_fixed_joints=True,
        replace_cylinders_with_capsules=False,
        asset_path=f"{ISAACLAB_ASSETS_DATA_DIR}/Robots/my_dog/newdog7/urdf/newdog7.urdf",
        activate_contact_sensors=True,
        rigid_props=sim_utils.RigidBodyPropertiesCfg(
            disable_gravity=False,
            retain_accelerations=False,
            linear_damping=0.0,
            angular_damping=0.0,
            max_linear_velocity=1000.0,
            max_angular_velocity=1000.0,
            max_depenetration_velocity=1.0,
        ),
        articulation_props=sim_utils.ArticulationRootPropertiesCfg(
            enabled_self_collisions=False, solver_position_iteration_count=4, solver_velocity_iteration_count=0
        ),
        joint_drive=sim_utils.UrdfConverterCfg.JointDriveCfg(
            gains=sim_utils.UrdfConverterCfg.JointDriveCfg.PDGainsCfg(stiffness=0, damping=0)
        ),
    ),
    init_state=ArticulationCfg.InitialStateCfg(
        pos=(0.0, 0.0, 0.285),
        joint_pos={
            
            "FR_hip_joint": 0.0,
            "FL_hip_joint": -0.0,
            "RR_hip_joint": -0.0,
            "RL_hip_joint": 0.0,

            "FR_thigh_joint": 1.0,
            "FL_thigh_joint": -1.0,
            "RR_thigh_joint": 1.0,
            "RL_thigh_joint": -1.0,

            "FR_calf_joint": 0.8,
            "FL_calf_joint": -0.8,
            "RR_calf_joint": 0.9,
            "RL_calf_joint": -0.9,
        }, 
        joint_vel={".*": 0.0},
    ),
    soft_joint_pos_limit_factor=0.9,
    actuators={
        "legs": ActuatorNetMLPCfg(
            joint_names_expr=[".*"],
            network_file=MY_DOG_ACTUATOR_NET_PATH,
            pos_scale=-1.0,
            vel_scale=1.0,
            torque_scale=1.0,
            input_order="pos_vel",
            input_idx=[0, 1, 2],
            effort_limit=16.8,
            saturation_effort=16.8,
            velocity_limit=32.5,
        ),
    },
)